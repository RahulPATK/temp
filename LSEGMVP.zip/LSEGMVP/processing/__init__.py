"""
Bundled processing modules for TapeSmith MCP Server.

Contains:
  - agents.py       — HeaderMappingAgent, ValueTransformationAgent, ValidationAgent, MCFGenerationAgent
  - data_processor.py — sanitize_df, process_data_types, transform_values
  - mcf_generator.py  — MCFProcessing class + create_mcf_data function
  - schema_loader.py   — load_schema (FUSE + Files API fallback)
  - file_loader.py     — load_tape_file (FUSE + SDK + REST fallback)
  - tag_generator.py   — NQM tag generation
  - model_config.py    — ModelConfig dataclass
"""

